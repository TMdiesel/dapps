import type { NextPage } from 'next'

const IndexPage: NextPage = () => {
    return (
        <>
            Hello!
        </>
    )
}

export default IndexPage